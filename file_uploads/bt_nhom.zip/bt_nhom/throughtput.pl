
$fileTrace = $ARGV[0];
$flowId = $ARGV[1];
$toNode = $ARGV[2];

$startTime = 0;
$endTime =0;

$sum =0;
open (DATA, "<$fileTrace") || die "Can't not open file $fileTrace $!";
while(<DATA>){
    @x = split(' ');

    if($x[0] eq 'r' && $x[7] == $flowId && $x[3] eq $toNode ){
        if($startTime == 0){
            $startTime = $x[1];
        }

        $sum = $sum + $x[5];
        $endTime = $x[1];
    }
}

$throughtputByte = $sum / ($endTime - $startTime);
$throughtputKbps = $throughtputByte*8/1024;

print STDOUT "\nKết quả:  Thông lượng trung bình(flow id = $flowId; dst Node = $toNode) = $throughtputByte (Byte/s) \n \n";
print STDOUT "Kết quả:  Thông lượng trung bình(flow id = $flowId; dst Node = $toNode) = $throughtputKbps (kbps) \n \n";

close DATA;
exit(0);