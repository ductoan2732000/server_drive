
$fileTrace = $ARGV[0];
$flowId = $ARGV[1];
$src = $ARGV[2];
$dst = $ARGV[3];

@send = (0..0);
@recv = (0..0);
$max_pktid = 0;
$sum = 0;

open (DATA ,"<$fileTrace") || die "can't open file $fileTrace";

while(<DATA>){
    @x = split(' ');

    $event = $x[0];
    $time = $x[1];
    $flow = $x[7];
    $pktId = $x[11];

    $node = $x[2] if ($event eq "+");
    $node = $x[3] if ($event eq "r");

    #Ghi thời điểm nhận và gửi gói tin vào mảng @send và @recv , ghi thông tin tổng số gói tin vào $sum
    if(($event eq "+") && ($flow == $flowId ) && ($node == $src) && (!$send[$pktId])){
        #kiểm tra (!$send[$pktId]) đảm bảo luôn tính gói tin được gửi lần đầu không tính gói tin gửi lại
        $send[$pktId] = $time;
        $max_pktid = $pktId if ($max_pktid < $pktId);
    }

    if(($event eq "r") && ($flow == $flowId) && ($node == $dst)){
        $recv[$pktId] = $time;
        $sum++;
    }
}
close DATA;

#Tính tổng thời gian trễ $delay rồi sau đó tính trễ trung bình $arv_delay

$delay = 0;
for ($count = 0 ; $count <= $max_pktid; $count++){
    if($send[$count] && $recv[$count]){
        $delay = $delay + ($recv[$count] - $send[$count]);
    }
}

$arv_delay = $delay/$sum;

print "\n Trễ trung bình trong thời gian mô phỏng =  $arv_delay (s) \n \n"